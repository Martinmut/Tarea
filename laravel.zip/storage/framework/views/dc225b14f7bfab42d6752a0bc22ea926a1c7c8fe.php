

<div class="form-group">
<label for="Nombre" class="control-label"><?php echo e('Nombre'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('Nombre')?'is-invalid':' '); ?>" name="Nombre" id="Nombre" 
value="<?php echo e(isset($empleado->Nombre)?$empleado->Nombre:old('Nombre')); ?>">
<?php echo $errors->first('Nombre', '<div class="invalid-feedback">:message</div>'); ?>


</div>


<div class="form-group">
<label for="ApellidoPaterno" class="control-label"><?php echo e('ApellidoPaterno'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('ApellidoPaterno')?'is-invalid':' '); ?>" name="ApellidoPaterno" id="ApellidoPaterno" 
value="<?php echo e(isset($empleado->ApellidoPaterno)?$empleado->ApellidoPaterno:old('ApellidoPaterno')); ?>">
<?php echo $errors->first('ApellidoPaterno', '<div class="invalid-feedback">:message</div>'); ?>


</div>

<div class="form-group">
<label for="ApellidoMaterno" class="control-label"><?php echo e('ApellidoMaterno'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('ApellidoMaterno')?'is-invalid':' '); ?>" name="ApellidoMaterno" id="ApellidoMaterno" 
value="<?php echo e(isset($empleado->ApellidoMaterno)?$empleado->ApellidoMaterno:old('ApellidoMaterno')); ?>">
<?php echo $errors->first('ApellidoMaterno', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="Correo" class="control-label"><?php echo e('Correo'); ?></label>
<input type="email" class="form-control <?php echo e($errors->has('Correo')?'is-invalid':' '); ?>" name="Correo" id="Correo" 
value="<?php echo e(isset($empleado->Correo)?$empleado->Correo:old('Correo')); ?>">
<?php echo $errors->first('Correo', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="Foto" class="control-label"><?php echo e('Foto'); ?></label>

<?php if(isset($empleado->Foto)): ?>
<br/>
<img src="<?php echo e(asset ('storage').'/'.$empleado->Foto); ?>" class="img-thumbnail img-fluid" alt="" width="200">
<br/>
<?php endif; ?>

<input class="form-control <?php echo e($errors->has('Foto')?'is-invalid':' '); ?>" type="file" name="Foto" id="Foto" value="">
<?php echo $errors->first('Foto', '<div class="invalid-feedback">:message</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='Crear' ? 'Agregar':'Modificar'); ?>">

<a class="btn btn-primary" href="<?php echo e(url('empleados')); ?>"> Regresar </a><?php /**PATH C:\xampp\htdocs\tarea\resources\views/empleados/form.blade.php ENDPATH**/ ?>